﻿var contentRow = $("#ContentRow");
var anchors = $("a.sub-menu-anchor");
var footer = $("footer");
var mainContent = $("#MainContent");
var menuContainer = $("#MenuContainer");
var fullWidthContainer = $(".full.width");
var topMenu = $("#TopMenu");
var datepickerLanguagePath;
var searchInput = $("#SearchInput");