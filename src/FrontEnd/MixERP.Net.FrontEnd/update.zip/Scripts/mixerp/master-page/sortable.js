﻿////Widget Support

$(document).ready(function() {
    $('#sortable-container').sortable({ placeholder: "ui-state-highlight", helper: 'clone', handle: 'div' });
});
