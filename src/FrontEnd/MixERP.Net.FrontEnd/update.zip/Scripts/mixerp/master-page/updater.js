﻿$(document).ready(function() {
    if (update === "1") {
        addNotification(Resources.Titles.Update(), "document.location = \"/Modules/Update.aspx\";");
    };
});