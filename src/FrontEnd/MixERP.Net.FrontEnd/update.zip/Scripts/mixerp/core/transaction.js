function convertToDebit(balanceInCredit) {
    return balanceInCredit * -1;
};