var confirmAction = function () {
    return confirm(Resources.Questions.AreYouSure());
};