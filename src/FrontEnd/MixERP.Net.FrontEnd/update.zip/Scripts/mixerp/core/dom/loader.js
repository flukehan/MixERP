function addLoader(el) {
    $(el).addClass('loading');
};

function removeLoader(el) {
    $(el).removeClass('loading');
};